package assign2;

import java.util.Random;
public class RandomGen {

	static Random rand = new Random();
	public static int[] generate(int n){
		int[] ranArr = new int[n];
		for(int i =0; i<n; i++){
			
			ranArr[i]=rand.nextInt(100)+1;
		}
		return ranArr;
	}
	
	 public static void display(int[]a){
		  for(int i =0; i<a.length;i++){
			  
				System.out.print(a[i]+" ");
			}
	  }
	 
	//works good!
	 
}
