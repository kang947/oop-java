package assign2;

/*
 * Q2) 
 * 		QSNormal trivially takes any elements from the passed array(conventionally the last-indexed element), 
 * 		and use it as a pivot. Then, it compares each element with the pivot, if the element is smaller than pivot, 
 * 		the number stays before the pivot, if bigger, it moves after the pivot. 
 * 		once the pivot moved to where it belongs in the array, the two segment of the array,
 * 		will repeat the quicksort algorithm, hence it is a divide-and-conquer algorithm.
 * 		QSMedian pivot choosing process is however not trivial: it takes the first, middle and last 
 * 		element of the array and the median element of the three element becomes its pivot. 
 * 		
 * 		
 * 	
 * 	Q3)
 * 		when the QSNormal method takes a sorted array AND the first or last element is chosen as its pivot,
 * 		it produces the worst case of the algorithm. it is because it creates a situation that one of the
 * 		partition always gets one element every time. One element is not required to be sorted but quick sort
 * 		algorithm is recursively applied to this single-element partition: waste of time. 
 * 		
 * 
 * 	Q4) describe how the pathological case performs given the Median of Three
 * 		reference performance tests that you run and your understanding of what
 */

public class QSDriver <T>{
	private static long startTime = System.nanoTime();
	//code
	private static long endTime= System.nanoTime();
	
	
	public static void main(String[]args){
		String totalLine= args[0];
		String s1= totalLine.substring(totalLine.indexOf("<")+1, totalLine.indexOf(">"));
		
		System.out.println(s1);
		
//		String sort = args[0];
//		String gen = args[1];
//		String length = args[2];
//		String seed = args[3];
		
		System.out.println("Took "+(endTime-startTime)+ "ns");
	}
}

